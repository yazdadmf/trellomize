import os
import time

current_dir = os.path.dirname(os.path.abspath(__file__))
employees_file_path = os.path.join(current_dir, "Employees.txt")

def print_usernames_from_file(file_path):
    with open(file_path, "r") as file:
        for line in file:
            if line.startswith("employee username:"):
                username = line.split(": ")[1].strip()
                print(username)
                
def disable_employee():
    with open(employees_file_path, "r") as file:
        data = file.readlines()
    print("All Usernames:")
    print_usernames_from_file(employees_file_path)
    print("List of Disabled Employees:")
    for line in range(0, len(data), 2):
        if data[line + 1].startswith("employee password: DISABLED"):
            username = data[line].replace("employee username: ", "").strip()
            print(f"- {username}")
            time.sleep(0.5)
    
    username = input("Enter the username of the employee to disable: ")
    
    with open(employees_file_path, "r") as file:
        data = file.readlines()
    
    with open(employees_file_path, "w") as file:
        disabled = False
        for line in range(0, len(data), 2):
            if "employee username: " + username + "\n" == data[line]:
                file.write("employee username: " + username + "\n")
                file.write("employee password: DISABLED\n")
                disabled = True
            else:
                file.write(data[line])
                file.write(data[line + 1])
        
        if disabled:
            print(f"Employee '{username}' account has been disabled.")
            time.sleep(0.5)
        else:
            print(f"Employee '{username}' not found.")
            time.sleep(0.5)

def enable_employee():
    with open(employees_file_path, "r") as file:
        data = file.readlines()
    
    print("List of Disabled Employees:")
    for line in range(0, len(data), 2):
        if data[line + 1].startswith("employee password: DISABLED"):
            username = data[line].replace("employee username: ", "").strip()
            print(f"- {username}")
            time.sleep(0.5)
    
    username = input("Enter the username of the employee to enable: ")
    
    with open(employees_file_path, "r") as file:
        data = file.readlines()
    
    with open(employees_file_path, "w") as file:
        enabled = False
        for line in range(0, len(data), 2):
            if "employee username: " + username + "\n" == data[line]:
                if data[line + 1].startswith("employee password: DISABLED"):
                    file.write(data[line])
                    password = input(f"Enter the new password for {username}: ")
                    file.write("employee password: " + password + "\n")
                    enabled = True
                else:
                    file.write(data[line])
                    file.write(data[line + 1])
            else:
                file.write(data[line])
                file.write(data[line + 1])
        
        if enabled:
            print(f"Employee '{username}' account has been enabled.")
            time.sleep(0.5)
        else:
            print(f"Employee '{username}' not found or not disabled.")
            time.sleep(0.5)