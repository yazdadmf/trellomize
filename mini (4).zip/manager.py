import os
import time
import manager_accessablty
import new_project_maker
import view_projects
import edit_projects

login = False

def manage_managers():
    # Get the current directory path
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, "managers.txt")

    def create_file_if_not_exists():
        if not os.path.exists(file_path):
            with open(file_path, "w") as file:
                pass

    def log_in():
        global username
        username = input("Enter your username: ")
        time.sleep(0.5)
        password = input("Enter your password: ")
        time.sleep(0.5)

        with open(file_path, "r") as file:
            data = file.readlines()
            for line in range(0, len(data), 2):
                if "manager username: " + username + "\n" == data[line] and "manager password: " + password + "\n" == data[line + 1]:
                    print("Login successful!")
                    time.sleep(0.5)
                    global login
                    login = True
                    return
            print("Invalid username or password. Please try again.")
            time.sleep(0.5)

    def main():
        create_file_if_not_exists()
        choice = choice1 = 0
        while True:
            choice = input("Choose an option:\n1. Log In\n2. Exit\n")
            time.sleep(0.5)

            if choice == "1":
                log_in()
                if(login):
                    print("\nHi Manager!")
                    while True:
                        choice1 = int(input("What do you want to do:\n1. Disable Employee Account\n2. Enable Employee Account\n3. Make New Project\n4. View All Projects\n5. Editing Projects\n6. Exit\n"))
                        if choice1 == 1:
                            manager_accessablty.disable_employee()
                        elif choice1 == 2:
                            manager_accessablty.enable_employee()
                        elif choice1 == 3:
                            new_project_maker.main()
                        elif choice1 == 4:
                            view_projects.main()
                        elif choice1 == 5:
                            edit_projects.main()
                        elif choice1 == 6:
                            print("Exiting...")
                            time.sleep(0.5)
                            exit()
                        else:
                            print("Invalid choice. Please try again.")
                else:
                    log_in()
            elif choice == "2":
                print("Exiting...")
                time.sleep(0.5)
                exit()
            else:
                print("Invalid choice. Please try again.")
                time.sleep(0.5)
    main()