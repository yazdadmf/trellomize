import os

current_dir = os.path.dirname(os.path.abspath(__file__))
projects_file_path = os.path.join(current_dir, "dataprojects.txt")

def Projects_edit(file_path):
    with open(file_path, "r") as file:
        lines = file.readlines()

    projects = []
    current_project = {}
    for line in lines:
        if line.strip() == "":
            if current_project:
                projects.append(current_project)
                current_project = {}
        else:
            parts = line.strip().split(": ", 1)
            if len(parts) == 2:
                key, value = parts
                current_project[key] = value

    if current_project:
        projects.append(current_project)

    print("Select a project to edit:")
    for i, project in enumerate(projects):
        print(f"{i + 1}. {project['Project Name']}")

    while True:
        project_choice = input("Enter the number of the project (or 'q' to quit): ").strip()
        if project_choice.lower() == 'q':
            break
        elif project_choice.isdigit() and 1 <= int(project_choice) <= len(projects):
            selected_project = projects[int(project_choice) - 1]
            break
        else:
            print("Invalid choice. Please enter a valid number.")

    while True:
        print("Select a phrase to change (or 'q' to quit):")
        for key in selected_project.keys():
            print(f"- {key}")
        phrases_to_change = []
        while True:
            phrase = input("Enter the phrase you want to edit: ").strip()
            if phrase.lower() == 'q':
                break
            if phrase in selected_project:
                phrases_to_change.append(phrase)
            else:
                print(f"'{phrase}' not found in the project.")

        for phrase in phrases_to_change:
            new_value = input(f"Enter the new value for '{phrase}': ").strip()
            selected_project[phrase] = new_value
            print(f"'{phrase}' updated to '{new_value}'.")

        if not phrases_to_change:
            print("No phrases selected for editing.")
        break


    for i, project in enumerate(projects):
        if project == selected_project:
            start = sum(len(line) for line in lines[:i])
            end = start + sum(len(line) for line in project.values()) + len(project) - 1
            lines[start:end] = [f"{key}: {value}\n" for key, value in project.items()]
            break

    with open(file_path, "w") as file:
        file.writelines(lines)

def main():
    Projects_edit(projects_file_path)
if __name__ == "__main__":
    main()
